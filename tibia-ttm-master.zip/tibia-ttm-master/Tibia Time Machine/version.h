#pragma once
#include <windows.h>

#define RES_VERSION 6,6,0,0
#define STR_VERSION "6.6"
#define TICKET "TTM66"

#define SITE_URL "otland.net"
#define DEV_YEAR "2022"

#define LATEST 1120
#define VERSION_EXAMPLES "7.0, 7.55, 8.3, 9.86, 10.54, 11.00, 11.20"
